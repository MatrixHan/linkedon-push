#!/bin/sh
javac -classpath .:/usr/java/jre/lib/rt.jar:/usr/local/lib/java/classes/sasl *.java
