/*
 * compile the plugins into the library for nice debugging
 */

#define NO_SASL_MONOLITHIC

/*
 * compiler doesnt allow an empty file
 */
typedef int xxx_sc_foo;
